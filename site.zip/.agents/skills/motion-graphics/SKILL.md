---
name: motion-graphics
description: >-
  World-class motion graphics expertise combining the animation principles of Disney, the kinetic typography of MK12, and the visual storytelling of studios like Buck and Ordinary Folk. Use when designing or implementing interactive animations, canvas simulations, transitions, and visual storytelling.
---

# Motion Graphics & Interactive Simulation Skill

Motion graphics transforms static ideas into dynamic visual experiences. Great motion graphics doesn't just move—it communicates. Every animation must have purpose: to guide attention, reinforce a message, create emotion, or clarify a scientific concept.

## Core Principles

1. **Every Movement Must Have Purpose**: Every particle, transition, and state change must directly clarify the scientific or conceptual truth of the step.
2. **Timing, Spacing & Easing Matter**: Never use jarring instantaneous jumps. Smooth in, smooth out—use continuous interpolation (`curr += (target - curr) * ease`) and organic easing curves.
3. **Less Is More — Restraint Shows Mastery**: Avoid cluttered overlapping text labels inside the canvas. Keep on-canvas leader lines minimal, crisp, and high-contrast, letting the visual storytelling and UI controls speak clearly.
4. **Motion Should Guide the Eye, Not Distract It**: Use focal glow, subtle depth-of-field, and clear spatial hierarchy so the user immediately understands where to look.
5. **Style Follows Message & Strict Text Alignment**: Keep every animation 100% faithful to the text content of its section—do not invent extraneous jargon that contradicts or distracts from the narrative bubbles.
6. **Direct Manipulation & Immediate Feedback**: Buttons and canvas clicks should trigger smooth camera zooms, state transitions, or physical responses with clear visual cause-and-effect.
