---
name: ui-design
description: >-
  World-class UI design expertise combining precision alignment, spatial dark-mode aesthetics, visual hierarchy, and intuitive interactive controls. Use when crafting visual interfaces, scientific widgets, and interactive canvas stages.
---

# UI Design Skill

UI design is the craft of making interfaces that feel effortless because they make the right thing obvious.

## Core Principles

1. **Clarity Beats Cleverness Every Time**: A user should understand what an interactive simulation demonstrates within 2 seconds of looking at it.
2. **Consistency Reduces Cognitive Load**: Maintain a unified spatial dark palette (`#030712` void background, `#38bdf8` cyan accents, `#10b981` emerald bio-tones, `#fbbf24` amber highlights, `#f472b6` magenta accents) across all simulations.
3. **Hierarchy Guides the Eye**: Separate primary subjects (foreground glowing cells/instruments) from secondary context (subtle grids, background fields) and keep typography crisp and non-overlapping.
4. **White Space is Breathing Room**: Never cram labels into the edges of the 460×270 viewport. Keep a clean margin around the stage and use 1–2 concise callout pins at most per state.
5. **Motion Should Inform, Not Decorate**: Every control button should correspond to a distinct, meaningful state or experimental step described in the text.
