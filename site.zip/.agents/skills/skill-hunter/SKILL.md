---
name: skill-hunter
description: >-
  Searches for external Antigravity skills, community packages, and SKILL.md definitions on GitHub, Google, and verified libraries. Use when asked to find, search for, or evaluate skills.
---

# Skill Hunter

This skill empowers the agent to find, evaluate, and recommend new skills from external sources.

## Capabilities

### 1. Search Strategy
When asked to "find a skill" or "search for skills," execute a multi-step search using these targeted queries:
- **GitHub Discovery**: `site:github.com "SKILL.md" "antigravity" OR "google antigravity" path:skills`
- **Community Libraries**: `site:github.com "antigravity-skills" OR "awesome-antigravity"`
- **Reddit Discussions**: `site:reddit.com "new skill" OR "custom skill"`
- **Official Docs**: `site:antigravity.google "skills library"`

### 2. Evaluation Criteria
Before recommending a skill, verify:
- **Presence of `SKILL.md`**: Does the repository actually contain valid skill definitions?
- **Safety**: Scan the description for executing arbitrary code or suspicious binaries.
- **Freshness**: Prioritize repositories updated within the last 6 months.

### 3. Installation Guidance
When presenting a found skill, always provide:
- **The Source**: A direct link to the GitHub repository or source file.
- **The Command**: The exact command to clone it (if applicable).
  ```bash
  # Example format
  git clone https://github.com/... .agents/skills/skill-name
  ```
- **The Summary**: A one-sentence description of what the skill adds to the agent.

## Verified Sources (Hardcoded)
Always check these known high-quality repositories first:
- `omer-metin/skills-for-antigravity` (Large collection of converted skills)
- `muhammedadnank/Antigravity-Skills` (Community curated)
